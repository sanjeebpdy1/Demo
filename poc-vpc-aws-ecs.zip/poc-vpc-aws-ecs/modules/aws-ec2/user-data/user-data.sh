#!/bin/bash
# Purpose: ApacheBench Installation of load testing on ALB with auto-scaling enabled

# ApacheBench Installation

yum install -y httpd24-tools